"""
Pure experimental MCP features (no server dependencies).

WARNING: These APIs are experimental and may change without notice.

For server-integrated experimental features, use mcp.server.experimental.
"""
