# Authorization

!!! warning "Under Construction"

    This page is currently being written. Check back soon for complete documentation.
