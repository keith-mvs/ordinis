import sys

from .main import main

sys.exit(main())  # type: ignore[call-arg]
