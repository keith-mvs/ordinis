"""SSE Polling Demo Server - demonstrates close_sse_stream for long-running tasks."""
